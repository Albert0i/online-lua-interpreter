export default {
  content: [
    "./src/public/views/**/*.html",
    "./src/views/**/*.ejs",
    "./src/public/scripts/**/*.{js,mjs}"
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}